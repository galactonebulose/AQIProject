import pandas as pd
import oracledb

# Function to clean and standardize column names
def clean_column_names(df):
    df.columns = df.columns.str.strip().str.lower().str.replace(" ", "_")
    return df

# Load CSV files and clean column names
csv_files = {
    "city": "S:/College/2ndYear/DBS LAb/Project/Data/formatted_city_data.csv",
    "stations": "S:/College/2ndYear/DBS LAb/Project/Data/formatted_monitoring_stations.csv",
    "trends": "S:/College/2ndYear/DBS LAb/Project/Data/formatted_air_quality_trends.csv",
    "health": "S:/College/2ndYear/DBS LAb/Project/Data/formatted_health_advice.csv",
    "pollutants":"S:/College/2ndYear/DBS LAb/Project/Data/formatted_pollutants.csv",
    "weather": "S:/College/2ndYear/DBS LAb/Project/Data/formatted_weather.csv"
}

dataframes = {key: clean_column_names(pd.read_csv(path)) for key, path in csv_files.items()}

# Column mappings from CSV to OracleDB schema
column_mappings = {
    "city": {"City": "cityname", "City ID": "cityid", "State": "statename", "Population": "population",
             "Region": "region", "LatitudeLongitude": "latitudelongitude", "Urban/Rural": "urbanrural", 
             "Cost of Living": "costofliving"},
    "stations": {"Station ID": "stationid", "StationName": "stationname", "City Name": "cityname", "State": "state",
                 "Status": "status", "City ID": "cityid", "AQI": "aqi", "Date of Construction": "dateofconstruction", 
                 "Cost of Installation": "costofinstallation", "Active Time": "activetime"},
    "trends": {"City ID": "cityid", "Start Date": "startdate", "End Date": "enddate", 
               "Average AQI": "averageaqi", "Max AQI": "maxaqi", "Min AQI": "minaqi", "Pollutants Observed": "pollutantsobserved"},
    "health": {"Advisory ID": "advisoryid", "AQI Range": "aqirange", "Category": "category", "Health Effects": "healtheffects",
               "Precautions": "precautions", "Lethality": "lethality", "Description": "description", "Age Affected": "ageaffected"},
    "pollutants": {"Pollutant ID": "pollutantid", "Pollutant Name": "pollutantname", "Safety Level": "safetylevel", 
                  "Units": "units", "Lethality": "lethality", "Sample Collection Date": "samplecollectiondate", 
                  "Effects on Environment": "effectsonenvironment", "Source of Pollutants": "sourceofpollutants"},
    "weather": {"Weather ID": "weatherid", "Station ID": "stationid", "Temperature": "temperature", "Humidity": "humidity",
                "Wind Speed": "windspeed", "Rainfall": "rainfall", "Wind Direction": "winddirection", 
                "Time of Measurement": "timeofmeasurement"}
}

# Function to rename columns based on mappings
def rename_columns(df, mapping):
    reverse_mapping = {v: k for k, v in mapping.items()}
    return df.rename(columns=reverse_mapping)

for table, df in dataframes.items():
    dataframes[table] = rename_columns(df, column_mappings[table])

# Configure OracleDB Connection
oracledb.init_oracle_client(lib_dir=r"S:/College/2ndYear/DBS LAb/instantclient_21_17")  
try:
    conn = oracledb.connect(user="system", password="Aaryan", dsn="AaryansLaptop:1521/XE")
    cursor = conn.cursor()
except oracledb.DatabaseError as e:
    print(f"Database connection error: {e}")
    exit(1)

# Function to safely retrieve values
def get_value(row, col_name):
    return None if pd.isna(row[col_name]) else row[col_name]

# Table insert queries
insert_queries = {
    "city": ("""
        INSERT INTO CITY (cityID, cityName, stateName, population, region, latitudeLongitude, urbanRural, costOfLiving)
        VALUES (city_seq.NEXTVAL, :1, :2, :3, :4, :5, :6, :7)
    """, ["cityName", "stateName", "population", "region", "latitudeLongitude", "urbanRural", "costOfLiving"]),
    
    "stations": ("""
        INSERT INTO MONITORING_STATIONS (stationID, cityID, latitudeLongitude, AQI, dateOfConstruction, costOfInstallation, activeTime)
        VALUES (station_seq.NEXTVAL, :1, :2, :3, TO_DATE(:4, 'YYYY-MM-DD'), :5, NUMTODSINTERVAL(:6, 'HOUR'))
    """, ["cityID", "latitudeLongitude", "AQI", "dateOfConstruction", "costOfInstallation", "activeTime"]),
    
    "trends": ("""
        INSERT INTO AIR_QUALITY_TRENDS (trendID, cityID, startDate, endDate, averageAQI, maxAQI, minAQI, pollutantsObserved)
        VALUES (trend_seq.NEXTVAL, :1, TO_DATE(:2, 'YYYY-MM-DD'), TO_DATE(:3, 'YYYY-MM-DD'), :4, :5, :6, :7)
    """, ["cityID", "startDate", "endDate", "averageAQI", "maxAQI", "minAQI", "pollutantsObserved"]),
    
    "health": ("""
        INSERT INTO HEALTH_ADVICE (advisoryID, AQIRange, category, healthEffects, precautions, lethality, description, ageAffected)
        VALUES (health_seq.NEXTVAL, :1, :2, :3, :4, :5, :6, :7)
    """, ["AQIRange", "category", "healthEffects", "precautions", "lethality", "description", "ageAffected"]),
    
    "pollutants": ("""
        INSERT INTO POLLUTANTS (pollutantID, pollutantName, safetyLevel, units, lethality, sampleCollectionDate, effectsOnEnvironment, sourceOfPollutants)
        VALUES (pollutant_seq.NEXTVAL, :1, :2, :3, :4, TO_DATE(:5, 'YYYY-MM-DD'), :6, :7)
    """, ["pollutantName", "safetyLevel", "units", "lethality", "sampleCollectionDate", "effectsOnEnvironment", "sourceOfPollutants"]),
    
    "weather": ("""
        INSERT INTO WEATHER (weatherID, stationID, temperature, humidity, windSpeed, rainfall, windDirection, timeOfMeasurement)
        VALUES (weather_seq.NEXTVAL, :1, :2, :3, :4, :5, :6, TO_DATE(:7, 'YYYY-MM-DD HH24:MI:SS'))
    """, ["stationID", "temperature", "humidity", "windSpeed", "rainfall", "windDirection", "timeOfMeasurement"])
}

# Insert Data into Database
for table, (query, columns) in insert_queries.items():
    df = dataframes.get(table, pd.DataFrame())
    if not df.empty:
        for _, row in df.iterrows():
            cursor.execute(query, tuple(get_value(row, col) for col in columns))

# Commit and Close Connection
conn.commit()
cursor.close()
conn.close()

print("Database sync complete!")
