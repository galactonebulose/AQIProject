import pandas as pd
import oracledb
import random
from datetime import datetime, timedelta

# File paths
stations_file = 'S:/College/2ndYear/DBS LAb/Project/New folder/stations.csv'
station_day_file = 'S:/College/2ndYear/DBS LAb/Project/New folder/station_day.csv'
city_hour_file = 'S:/College/2ndYear/DBS LAb/Project/New folder/city_hour.csv'
city_day_file = 'S:/College/2ndYear/DBS LAb/Project/New folder/city_day.csv'

# Load CSV data
def load_csv(file_path):
    try:
        return pd.read_csv(file_path)
    except Exception as e:
        print(f"Error loading {file_path}: {e}")
        return pd.DataFrame()

stations_df = load_csv(stations_file)
station_day_df = load_csv(station_day_file)
city_hour_df = load_csv(city_hour_file)
city_day_df = load_csv(city_day_file)

# Configure OracleDB Connection
oracledb.init_oracle_client(lib_dir=r"S:/College/2ndYear/DBS LAb/instantclient_21_17")

# Connect to Oracle SQL*Plus database
try:
    conn = oracledb.connect(user="system", password="Aaryan", dsn="AaryansLaptop:1521/XE")
    cursor = conn.cursor()
except oracledb.DatabaseError as e:
    print(f"Database connection error: {e}")
    exit(1)

# Insert into CITY
for _, row in city_day_df.iterrows():
    cursor.execute('''
        INSERT INTO CITY (cityID, cityName, stateName, population, region, latitudeLongitude, urbanRural, costOfLiving)
        VALUES (city_seq.NEXTVAL, :1, :2, :3, :4, :5, :6, :7)
    ''', (row['City'], row['State'], random.randint(500000, 30000000), row['Region'], f"{random.uniform(10, 40)},{random.uniform(60, 90)}", "Urban", random.uniform(50, 150)))

# Insert into MONITORING_STATIONS
cursor.execute("SELECT cityID FROM CITY")
city_ids = [row[0] for row in cursor.fetchall()]

for city_id in city_ids:
    cursor.execute('''
        INSERT INTO MONITORING_STATIONS (stationID, cityID, latitudeLongitude, AQI, dateOfConstruction, costOfInstallation, activeTime)
        VALUES (station_seq.NEXTVAL, :1, :2, :3, TO_DATE(:4, 'YYYY-MM-DD'), :5, NUMTODSINTERVAL(:6, 'HOUR'))
    ''', (city_id, f"{random.uniform(10, 40)},{random.uniform(60, 90)}", random.randint(50, 400), "2005-06-15", random.uniform(10000, 50000), 8))

# Insert into AIR_QUALITY_TRENDS
for city_id in city_ids:
    cursor.execute('''
        INSERT INTO AIR_QUALITY_TRENDS (trendID, cityID, startDate, endDate, averageAQI, maxAQI, minAQI, pollutantsObserved)
        VALUES (trend_seq.NEXTVAL, :1, TO_DATE(:2, 'YYYY-MM-DD'), TO_DATE(:3, 'YYYY-MM-DD'), :4, :5, :6, :7)
    ''', (city_id, "2024-01-01", "2024-12-31", random.randint(50, 250), random.randint(300, 400), random.randint(30, 50), "PM2.5, NO2"))

# Insert into HEALTH_ADVICE
health_advice_samples = [
    ("0-50", "Good", "Minimal impact", "No precautions needed", "Low", "Clean air, safe for all", "All"),
    ("51-100", "Moderate", "Mild impact on sensitive groups", "Reduce prolonged outdoor activities", "Medium", "Acceptable air quality", "Children, Elderly")
]

for advice in health_advice_samples:
    cursor.execute('''
        INSERT INTO HEALTH_ADVICE (advisoryID, AQIRange, category, healthEffects, precautions, lethality, description, ageAffected)
        VALUES (health_seq.NEXTVAL, :1, :2, :3, :4, :5, :6, :7)
    ''', advice)

# Insert into POLLUTANTS
pollutants_samples = [
    ("CO", 9.0, "ppm", "Moderate", "2025-01-10", "Contributes to smog", "Vehicle emissions"),
    ("NO2", 0.05, "ppm", "High", "2025-01-12", "Acid rain, respiratory issues", "Industrial combustion")
]

for pollutant in pollutants_samples:
    cursor.execute('''
        INSERT INTO POLLUTANTS (pollutantID, pollutantName, safetyLevel, units, lethality, sampleCollectionDate, effectsOnEnvironment, sourceOfPollutants)
        VALUES (pollutant_seq.NEXTVAL, :1, :2, :3, :4, TO_DATE(:5, 'YYYY-MM-DD'), :6, :7)
    ''', pollutant)

# Insert into WEATHER_CONDITIONS & AIR_QUALITY_DATA
for _, row in city_hour_df.iterrows():
    timestamp = row['Datetime']
    city_name = row['City']
    
    # Fetch cityID
    cursor.execute("SELECT cityID FROM CITY WHERE cityName = :1", (city_name,))
    city = cursor.fetchone()
    if city:
        city_id = city[0]

        # Insert into AIR_QUALITY_DATA
        cursor.execute('''
            INSERT INTO AIR_QUALITY_DATA (recordID, cityID, timestamp, AQI, PM2_5, PM10, CO, NO2, SO2, O3)
            VALUES (air_quality_seq.NEXTVAL, :1, TO_DATE(:2, 'YYYY-MM-DD HH24:MI:SS'), :3, :4, :5, :6, :7, :8, :9)
        ''', (city_id, timestamp, row['AQI'], row['PM2.5'], row['PM10'], row['CO'], row['NO2'], row['SO2'], row['O3']))

        # Insert into WEATHER_CONDITIONS
        cursor.execute('''
            INSERT INTO WEATHER_CONDITIONS (weatherID, cityID, timestamp, temperature, humidity, windSpeed, pressure, weatherCondition)
            VALUES (weather_seq.NEXTVAL, :1, TO_DATE(:2, 'YYYY-MM-DD HH24:MI:SS'), :3, :4, :5, :6, :7)
        ''', (city_id, timestamp, row['Temperature'], row['Humidity'], row['WindSpeed'], row['Pressure'], row['Weather']))

# Commit changes and close connection
conn.commit()
cursor.close()
conn.close()

print("✅ All Data Successfully Inserted!")
